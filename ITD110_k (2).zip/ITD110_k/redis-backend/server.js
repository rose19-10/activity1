const express = require('express');
const redis = require('redis');
const cors = require('cors');
const bodyParser = require('body-parser');
const multer = require('multer');
const fs = require('fs');
const csv = require('fast-csv');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Connect to Redis
const client = redis.createClient({
  url: 'redis://127.0.0.1:6379'  // Fixed Redis connection
});

client.connect()
  .then(() => console.log('Connected to Redis'))
  .catch(err => console.error('Redis connection error:', err));
  
  // Handle Redis errors globally
client.on('error', (err) => {
  console.error('Redis error:', err);
});

// Multer setup for file uploads
const upload = multer({ dest: 'uploads/' });

// Import CSV file
app.post('/students/import', upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No file uploaded' });
  }

  const filePath = req.file.path;
  const students = [];

  fs.createReadStream(filePath)
    .pipe(csv.parse({ headers: true }))
    .on('data', (row) => students.push(row))
    .on('end', async () => {
      fs.unlinkSync(filePath);
      try {
        for (const student of students) {
          const { id, name, course, age, address, email, gender, birthdate } = student;
          const existingStudent = await client.hGetAll(`student:${id}`);
          if (Object.keys(existingStudent).length === 0) {
            await client.hSet(`student:${id}`, {
              name, course, age, address, email, gender, birthdate
            });
          }
        }
        res.status(200).json({ message: 'CSV data imported successfully' });
      } catch (error) {
        console.error('Error importing CSV:', error);
        res.status(500).json({ message: 'Failed to import CSV' });
      }
    });
});

// Export student data to CSV
app.get('/students/export', async (req, res) => {
  try {
    const keys = await client.keys('student:*');
    const students = await Promise.all(keys.map(async (key) => {
      return { id: key.split(':')[1], ...(await client.hGetAll(key)) };
    }));

    const csvStream = csv.format({ headers: true });
    res.setHeader('Content-Disposition', 'attachment; filename=students.csv');
    res.setHeader('Content-Type', 'text/csv');

    csvStream.pipe(res);
    students.forEach(student => csvStream.write(student));
    csvStream.end();
  } catch (error) {
    console.error('Error exporting CSV:', error);
    res.status(500).json({ message: 'Failed to export CSV' });
  }
});

// CRUD Operations

// Route to save student data
app.post('/students', async (req, res) => {
  const { id, name, course, age, address, email, gender, birthdate } = req.body;

  if (!id || !name || !course || !age || !address || !email || !gender || !birthdate) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    const studentData = { name, course, age, address, email, gender, birthdate };

    await client.hSet(`student:${id}`, 'name', studentData.name);
    await client.hSet(`student:${id}`, 'course', studentData.course);
    await client.hSet(`student:${id}`, 'age', studentData.age);
    await client.hSet(`student:${id}`, 'address', studentData.address);
    await client.hSet(`student:${id}`, 'email', studentData.email);
    await client.hSet(`student:${id}`, 'gender', studentData.gender);
    await client.hSet(`student:${id}`, 'birthdate', studentData.birthdate);

    res.status(201).json({ message: 'Student saved successfully' });
  } catch (error) {
    console.error('Error saving student:', error);
    res.status(500).json({ message: 'Failed to save student' });
  }
});

// Read (R)
app.get('/students/:id', async (req, res) => {
  const id = req.params.id;
  const student = await client.hGetAll(`student:${id}`);
  if (Object.keys(student).length === 0) {
    return res.status(404).json({ message: 'Student not found' });
  }
  res.json(student);
});

// Read all students
app.get('/students', async (req, res) => {
  const keys = await client.keys('student:*');
  const students = await Promise.all(keys.map(async (key) => {
    return { id: key.split(':')[1], ...(await client.hGetAll(key)) };
  }));
  res.json(students);
});

app.get('/students/search', async (req, res) => {
  const { keyword } = req.query;
  if (!keyword) {
    return res.status(400).json({ message: 'Search keyword is required' });
  }

  try {
    const keys = await client.keys('student:*');
    const students = await Promise.all(keys.map(async (key) => {
      return { id: key.split(':')[1], ...(await client.hGetAll(key)) };
    }));

    // Filter students by name (case-insensitive)
    const filteredStudents = students.filter(student =>
      student.name.toLowerCase().includes(keyword.toLowerCase())
    );

    res.json(filteredStudents);
  } catch (error) {
    console.error('Error searching students:', error);
    res.status(500).json({ message: 'Failed to search students' });
  }
});

// Update (U)
app.put('/students/:id', async (req, res) => {
  const id = req.params.id;
  const { name, course, age, address, email, gender, birthdate} = req.body;

  if (!name && !course && !age && !address && !email && !gender && !birthdate) {
    return res.status(400).json({ message: 'At least one field is required to update' });
  }

  try {
    const existingStudent = await client.hGetAll(`student:${id}`);
    if (Object.keys(existingStudent).length === 0) {
      return res.status(404).json({ message: 'Student not found' });
    }

    if (name) await client.hSet(`student:${id}`, 'name', name);
    if (course) await client.hSet(`student:${id}`, 'course', course);
    if (age) await client.hSet(`student:${id}`, 'age', age);
    if (address) await client.hSet(`student:${id}`, 'address', address);
    if (email) await client.hSet(`student:${id}`, 'email', email);
    if (gender) await client.hSet(`student:${id}`, 'gender', gender);
    if (birthdate) await client.hSet(`student:${id}`, 'birthdate', birthdate);

    res.status(200).json({ message: 'Student updated successfully' });
  } catch (error) {
    console.error('Error updating student:', error);
    res.status(500).json({ message: 'Failed to update student' });
  }
});

// Delete (D)
app.delete('/students/:id', async (req, res) => {
  const id = req.params.id;
  await client.del(`student:${id}`);
  res.status(200).json({ message: 'Student deleted successfully' });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});