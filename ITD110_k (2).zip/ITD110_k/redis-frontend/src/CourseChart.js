import React from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid } from "recharts";

const CourseChart = ({ data }) => {
  return (
    <div style={{ padding: '20px', backgroundColor: '#fff', borderRadius: '8px', boxShadow: '0 0 20px rgba(0, 0, 0, 0.1)' }}>
      <h2 style={{ color: '#00b3b3', marginBottom: '20px' }}>Student per Course Analytics</h2>
      <ResponsiveContainer width="100%" height={400}>
        <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 10 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="course" stroke="#00b3b3" />
          <YAxis stroke="#00b3b3" />
          <Tooltip contentStyle={{ backgroundColor: '#00b3b3', color: '#004d4d' }} />
          <Legend />
          <Bar dataKey="count" fill="#004d4d" barSize={50} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default CourseChart;