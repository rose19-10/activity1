import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import reportWebVitals from "./reportWebVitals";

// ✅ Ensure the root element exists
const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Root element not found! Check your index.html.");
}

// ✅ Create React root
const root = ReactDOM.createRoot(rootElement);

root.render(
  <React.StrictMode>
    <App /> {/* ✅ Directly rendering App.js */}
  </React.StrictMode>
);

// ✅ Performance tracking (optional)
reportWebVitals();
