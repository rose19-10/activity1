import React, { useState, useEffect } from "react";
import axios from "axios";
import Papa from "papaparse"; // Import PapaParse for CSV handling
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import CourseChart from "./CourseChart"; // Import the CourseChart component
import "./App.css"; // Import the CSS file

const API_URL = "http://localhost:5000/students";

function App() {
  const [formData, setFormData] = useState({
    id: "",
    name: "",
    course: "",
    age: "",
    address: "",
    email: "",
    gender: "",
    birthdate: "",
  });

  const [students, setStudents] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  // Fetch all students
  const fetchStudents = async () => {
    try {
      const response = await axios.get(API_URL);
      setStudents(response.data);
    } catch (error) {
      console.error("Error fetching students:", error);
      toast.error("Failed to fetch students");
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  // Handle form change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Add new student
  const handleAddSubmit = async (e) => {
    e.preventDefault();
    try {
      const newStudent = { ...formData, id: students.length + 1 }; // Generate a unique ID
      await axios.post(API_URL, newStudent);
      toast.success("Student added successfully!");
      fetchStudents();
      setFormData({
        id: "",
        name: "",
        course: "",
        age: "",
        address: "",
        email: "",
        gender: "",
        birthdate: "",
      });
    } catch (error) {
      toast.error("Error adding student!");
    }
  };

  // Update existing student
  const handleEditSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`${API_URL}/${formData.id}`, formData);
      toast.success("Student updated successfully!");
      fetchStudents();
      setFormData({
        id: "",
        name: "",
        course: "",
        age: "",
        address: "",
        email: "",
        gender: "",
        birthdate: "",
      });
      setIsEditing(false);
    } catch (error) {
      toast.error("Error updating student!");
    }
  };

  // Delete student
  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API_URL}/${id}`);
      toast.success("Student deleted!");
      fetchStudents();
    } catch (error) {
      toast.error("Error deleting student!");
    }
  };

  // Populate form for updating student
  const handleEdit = (student) => {
    setFormData(student);
    setIsEditing(true);
  };

  // Search function
  const handleSearch = (e) => {
    setSearchTerm(e.target.value); // Update search term
  };

  // Filter students based on search term
  const filteredStudents = students.filter((student) =>
  (student.name && student.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
  (student.course && student.course.toLowerCase().includes(searchTerm.toLowerCase())) ||
  (student.address && student.address.toLowerCase().includes(searchTerm.toLowerCase()))
);

  // Process student data to get course counts
  const getCourseCounts = () => {
    const courseMap = {};

    students.forEach((student) => {
      if (courseMap[student.course]) {
        courseMap[student.course]++;
      } else {
        courseMap[student.course] = 1;
      }
    });

    return Object.keys(courseMap).map((course) => ({
      course,
      count: courseMap[course],
    }));
  };

  const handleCSVUpload = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    Papa.parse(file, {
      complete: (result) => {
        const parsedData = result.data;
        const formattedData = parsedData.slice(1).map((row, index) => {
          // Check if the row is not empty
          if (row.some(cell => cell.trim() !== "")) {
            return {
              id: students.length + index + 1, // Ensure unique IDs
              name: row[0],
              course: row[1],
              age: row[2],
              address: row[3],
              email: row[4],
              gender: row[5],
              birthdate: row[6],
            };
          }
          return null;
        }).filter(row => row !== null); // Filter out null rows

        setStudents((prevStudents) => [...prevStudents, ...formattedData]);
        toast.success("CSV file imported successfully!");
      },
      header: false,
    });
  };

  // Export student data to CSV
  const exportToCSV = () => {
    const csvData = [
      ["Name", "Course", "Age", "Address", "Email", "Gender", "Birthdate"],
      ...students.map((s) => [s.name, s.course, s.age, s.address, s.email, s.gender, s.birthdate]),
    ];
    const csv = Papa.unparse(csvData);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.setAttribute("download", "students.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Scroll to section
  const scrollToSection = (id) => {
    document.getElementById(id).scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="app-container">
      <div className="taskbar">
        <button onClick={() => scrollToSection("courseChartSection")}>
          <i className="fas fa-chart-bar"></i>
        </button>
        <button onClick={() => scrollToSection("addStudentSection")}>
          <i className="fas fa-user-plus"></i>
        </button>
        <button onClick={() => scrollToSection("studentListSection")}>
          <i className="fas fa-list"></i>
        </button>
      </div>
      <div className="container">
        <h1>STUDENT DATA MANAGEMENT</h1>
        <div id="courseChartSection" className="section">
          <CourseChart data={getCourseCounts()} />
        </div>
        <div id="addStudentSection" className="section">
          <div className="file-upload">
            <label htmlFor="csvUpload" className="file-upload-label">
              Upload CSV
              <input type="file" id="csvUpload" accept=".csv" onChange={handleCSVUpload} className="file-upload-input" />
            </label>
            <button onClick={exportToCSV} className="export-button">Export CSV</button>
          </div>
          {!isEditing ? (
            <form onSubmit={handleAddSubmit} className="genz-form">
              <input type="text" name="name" placeholder="Name" value={formData.name} onChange={handleChange} required />
              <input type="text" name="course" placeholder="Course" value={formData.course} onChange={handleChange} required />
              <input type="number" name="age" placeholder="Age" value={formData.age} onChange={handleChange} required />
              <input type="text" name="address" placeholder="Address" value={formData.address} onChange={handleChange} required />
              <input type="email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} required />
              <select name="gender" value={formData.gender} onChange={handleChange} required>
                <option value="">Select Gender</option>
                <option value="Female">Female</option>
                <option value="Male">Male</option>
                <option value="Other">Other</option>
              </select>
              <input type="date" name="birthdate" placeholder="Birth Date" value={formData.birthdate} onChange={handleChange} required />
              <button type="submit">Add Student</button>
            </form>
          ) : (
            <form onSubmit={handleEditSubmit} className="genz-form">
              <input type="text" name="id" placeholder="ID" value={formData.id} onChange={handleChange} required disabled />
              <input type="text" name="name" placeholder="Name" value={formData.name} onChange={handleChange} required />
              <input type="text" name="course" placeholder="Course" value={formData.course} onChange={handleChange} required />
              <input type="number" name="age" placeholder="Age" value={formData.age} onChange={handleChange} required />
              <input type="text" name="address" placeholder="Address" value={formData.address} onChange={handleChange} required />
              <input type="email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} required />
              <select name="gender" value={formData.gender} onChange={handleChange} required>
                <option value="">Select Gender</option>
                <option value="Female">Female</option>
                <option value="Male">Male</option>
                <option value="Other">Other</option>
              </select>
              <input type="date" name="birthdate" placeholder="Birth Date" value={formData.birthdate} onChange={handleChange} required />
              <button type="submit">Update Student</button>
            </form>
          )}
        </div>
        <h2 id="studentListSection" className="section">Student List</h2>
        <input
          type="text"
          placeholder="Search by name, course, or address..."
          value={searchTerm}
          onChange={handleSearch}
        />
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Course</th>
              <th>Age</th>
              <th>Address</th>
              <th>Email</th>
              <th>Gender</th>
              <th>Birth Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredStudents.map((student) => (
              <tr key={student.id}>
                <td>{student.id}</td>
                <td>{student.name}</td>
                <td>{student.course}</td>
                <td>{student.age}</td>
                <td>{student.address}</td>
                <td>{student.email}</td>
                <td>{student.gender}</td>
                <td>{student.birthdate}</td>
                <td>
                  <button onClick={() => handleEdit(student)}>Edit</button>
                  <button onClick={() => handleDelete(student.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <ToastContainer />
      </div>
    </div>
  );
}

export default App;